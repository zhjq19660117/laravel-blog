<?php

namespace MongoDB\Exception;

interface Exception extends \MongoDB\Driver\Exception\Exception
{
}
